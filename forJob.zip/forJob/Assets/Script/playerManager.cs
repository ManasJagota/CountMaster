﻿using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;


public class playerManager : MonoBehaviour
{
    public Transform player;
    private int countStickmans;
    [SerializeField] private TextMeshPro CounterTxt;
    public bool spawn;
    [SerializeField] private GameObject stickMan;

    public GameObject finishPanel;
    public GameObject env;
    public GameObject play;
    [SerializeField] private TextMeshProUGUI FinishTxt;

    [Range(0f,1f)] [SerializeField] private float distanceFactor, Radius;

    public bool moveByTouch, gameState;
    private Vector3 mouseStartPos, playerStartPos;
    public float playerSpeed, roadSpeed;
    private Camera cam;

    [SerializeField] private Transform road;


    void Start()
    {
        player = transform;
        countStickmans = transform.childCount;
        CounterTxt.text = (countStickmans - 1).ToString();
        cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
    

        moveThePlayer();
        if (gameState)
        {
            road.Translate(-(road.forward * Time.deltaTime * roadSpeed));
        }
    }

    void moveThePlayer()
    {
        if(Input.GetMouseButtonDown(0) && gameState)
        {
            moveByTouch = true;
            var plane = new Plane(Vector3.up, 0f);
            var ray = cam.ScreenPointToRay(Input.mousePosition);

            if(plane.Raycast(ray, out var distance))
            {
                mouseStartPos = ray.GetPoint(distance + 1f);
                playerStartPos = transform.position;
            }
        }
        if(Input.GetMouseButtonUp(0))
        {
            moveByTouch = false;
        }
        if(moveByTouch)
        {
            var plane = new Plane(Vector3.up, 0f);
            var ray = cam.ScreenPointToRay(Input.mousePosition);

            if(plane.Raycast(ray, out var distance))
            {
                var mousePos = ray.GetPoint(distance + 1f);
                var move = mousePos - mouseStartPos;
                var control = playerStartPos + move;

                if(countStickmans > 50)
                    control.x = Mathf.Clamp(control.x, -4f, 3.5f);
                else
                    control.x = Mathf.Clamp(control.x, -5f, 5f);

                transform.position = new Vector3(Mathf.Lerp(transform.position.x, control.x, Time.deltaTime * playerSpeed), transform.position.y, transform.position.z);
            }
        }

      
    }

    private void makeStickMan(int number)
    {
        for(int i= 0; i<number;i++)
        {
            Instantiate(stickMan,transform.position, Quaternion.identity, transform);
        }
        countStickmans = transform.childCount;
        CounterTxt.text = (countStickmans - 1).ToString();
        formatStickMan();
    }

    private void formatStickMan()
    {
        for(int i=1; i<player.childCount; i++)
        {
            var x = distanceFactor * Mathf.Sqrt(i) * Mathf.Cos(i * Radius);
            var z = distanceFactor * Mathf.Sqrt(i) * Mathf.Sin(i * Radius);

            var newPos = new Vector3(x, 0f, z);


            player.transform.GetChild(i).DOLocalMove(newPos, 1f).SetEase(Ease.OutBack);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Gate"))
        {
            other.transform.parent.GetChild(0).GetComponent<BoxCollider>().enabled = false;   //for gate 1
            other.transform.parent.GetChild(1).GetComponent<BoxCollider>().enabled = false;   //for gate 2
            spawn = true;
            var gateMan = other.GetComponent<gateManager>();

            if(gateMan.multiply)
            {
                makeStickMan(countStickmans * gateMan.randomNo);
            }
           else
            {
                makeStickMan((countStickmans - 4) + gateMan.randomNo);
            }
        }

      
        if (other.CompareTag("enemy"))
        {
           
            StartCoroutine(rebind());
        }
        
        else if(other.CompareTag("Finish"))
        {
            
            finishPanel.SetActive(true);
            countStickmans = transform.childCount - 1;
            FinishTxt.text = (countStickmans-1).ToString();
            play.SetActive(false);
            env.SetActive(false);
        }
    }
    IEnumerator rebind()
    {
        yield return new WaitForSeconds(1f);
        countStickmans = transform.childCount - 1;
        CounterTxt.text = (countStickmans-1).ToString();
        formatStickMan();
    }
}
