﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class gateManager : MonoBehaviour
{
    public TextMeshPro GateNo;
    public int randomNo;
    public bool multiply;
    void Start()
    {
        if(multiply)
        {
            randomNo = Random.RandomRange(1, 3);
            GateNo.text = "X" + randomNo;
        }
        else
        {
            randomNo = Random.RandomRange(10, 100);
            if(randomNo % 2 !=0)
            {
                randomNo += 1;
            }
            GateNo.text = (randomNo).ToString();
        }
    }
}
