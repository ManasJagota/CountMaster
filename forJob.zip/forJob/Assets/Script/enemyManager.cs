using UnityEngine;
using TMPro;
using DG.Tweening;
public class enemyManager : MonoBehaviour
{
    [SerializeField] public GameObject stickMan;
    [SerializeField] public TextMeshPro CounterTxt;

    public Transform enemy;
    public bool attack;
    // Start is called before the first frame update
    void Start()
    {

        CounterTxt.text = (transform.childCount+1).ToString();
    }

    public void AttackThem(Transform enemyForce)
    {
        enemy = enemyForce;
        attack = true;
    }
}
