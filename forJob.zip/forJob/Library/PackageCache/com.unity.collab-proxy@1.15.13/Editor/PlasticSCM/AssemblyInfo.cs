using System.Runtime.CompilerServices;
using UnityEngine;

[assembly: InternalsVisibleTo("Unity.PlasticSCM.EditorTests")]
[assembly: InternalsVisibleTo("Unity.PlasticSCM.DevTools")]